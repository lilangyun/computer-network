/******************************************************************************
* echo_client.c                                                               *
*                                                                             *
* Description: This file contains the C source code for an echo client.  The  *
*              client connects to an arbitrary <host,port> and sends input    *
*              from stdin.                                                    *
*                                                                             *
* Authors: Athula Balachandran <abalacha@cs.cmu.edu>,                         *
*          Wolf Richter <wolf@cs.cmu.edu>                                     *
*                                                                             *
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>

#define ECHO_PORT 9999
#define BUF_SIZE 4096

int main(int argc, char* argv[])
{
    if (argc != 4)
    {
        fprintf(stderr, "usage: %s <server-ip> <port> <file-path>\n",argv[0]);
        return EXIT_FAILURE;
    }

    char buf[BUF_SIZE];
        
    int status, sock;
    struct addrinfo hints;
	memset(&hints, 0, sizeof(struct addrinfo));
    struct addrinfo *servinfo; //will point to the results
    hints.ai_family = AF_INET;  //IPv4
    hints.ai_socktype = SOCK_STREAM; //TCP stream sockets
    hints.ai_flags = AI_PASSIVE; //fill in my IP for me

    if ((status = getaddrinfo(argv[1], argv[2], &hints, &servinfo)) != 0) 
    {
        fprintf(stderr, "getaddrinfo error: %s \n", gai_strerror(status));
        return EXIT_FAILURE;
    }

    if((sock = socket(servinfo->ai_family, servinfo->ai_socktype, servinfo->ai_protocol)) == -1)
    {
        fprintf(stderr, "Socket failed\n");
        return EXIT_FAILURE;
    }
    
    if (connect (sock, servinfo->ai_addr, servinfo->ai_addrlen) == -1)
    {
        fprintf(stderr, "Connect\n");
        return EXIT_FAILURE;
    }

    // 评测平台是通过文件去检测的
    int fd = open(argv[3], O_RDONLY); 
    char msg[BUF_SIZE], send_buf[BUF_SIZE];
    int readret = read(fd, msg, BUF_SIZE);
    char *ptr = strstr(msg, "\r\n\r\n");
    char *tmp = msg;

    while( ptr != NULL) {
        // 追加"\r\n"
        memcpy(send_buf, tmp, ptr - tmp + 4);
        
        // send all only once
        send(sock, send_buf, strlen(send_buf), 0);  //  send msg
        fprintf(stdout, "Sending:\n");
        fprintf(stdout, "%s", send_buf);  // hints

        // 接收MESSAGE
        int bytes_received;
        if((bytes_received = recv(sock, buf, BUF_SIZE, 0)) > 1)
        {
            buf[bytes_received] = '\0';
            fprintf(stdout, "Received:\n");
            fprintf(stdout, "%s", buf);
        }

        // ptr指向下一个request
        char *tmp = ptr + 4;
        ptr = strstr(tmp, "\r\n\r\n");
    }

    freeaddrinfo(servinfo);
    close(sock);    
    return EXIT_SUCCESS;
}
