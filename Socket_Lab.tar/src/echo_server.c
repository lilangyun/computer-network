/******************************************************************************
* echo_server.c                                                               *
*                                                                             *
* Description: This file contains the C source code for an echo server.  The  *
*              server runs on a hard-coded port and simply write back anything*
*              sent to it by connected clients.  It does not support          *
*              concurrent clients.                                            *
*                                                                             *
* Authors: Athula Balachandran <abalacha@cs.cmu.edu>,                         *
*          Wolf Richter <wolf@cs.cmu.edu>                                     *
*                                                                             *
*******************************************************************************/

#include <netinet/in.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "parse.h"

#define ECHO_PORT 9999
#define BUF_SIZE 4096

const char *RESPONSE_200 = "HTTP/1.1 200 OK\r\n";
const char *RESPONSE_400 = "HTTP/1.1 400 Bad request\r\n\r\n";
const char *RESPONSE_404 = "HTTP/1.1 404 Not Found\r\n\r\n";
const char *RESPONSE_501 = "HTTP/1.1 501 Not Implemented\r\n\r\n";
const char *RESPONSE_505 = "HTTP/1.1 505 HTTP Version not supported\r\n\r\n";

const char *URI_Default = "static_site/index.html";

const char *Header_Default = "Content-Length";

// 日志模块
void ERROR_LOG(char *file_path){
    FILE *fd = fopen("error.log", "a");

    fprintf(fd, "ErrorLog %s\n", file_path);

    fclose(fd);
}

int is_dir(char *file_path);
void add_header(Request *request, char *sbuf, char *file_path);
void handle_request(Request *request, char *buf, char *sbuf, int client_sock);

int close_socket(int sock)
{
    if (close(sock))
    {
        fprintf(stderr, "Failed closing socket.\n");
        return 1;
    }
    return 0;
}

int main(int argc, char* argv[])
{
    int sock, client_sock;
    ssize_t readret;
    socklen_t cli_size;
    struct sockaddr_in addr, cli_addr;
    char buf[8192];  // 接收Buf
    char sbuf[8192];  // 发送Buf

    fprintf(stdout, "----- Echo Server -----\n");
    
    /* all networked programs must create a socket */
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        fprintf(stderr, "Failed creating socket.\n");
        return EXIT_FAILURE;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ECHO_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    /* servers bind sockets to ports---notify the OS they accept connections */
    if (bind(sock, (struct sockaddr *) &addr, sizeof(addr)))
    {
        close_socket(sock);
        fprintf(stderr, "Failed binding socket.\n");
        return EXIT_FAILURE;
    }

    if (listen(sock, 5))
    {
        close_socket(sock);
        fprintf(stderr, "Error listening on socket.\n");
        return EXIT_FAILURE;
    }

    /* finally, loop waiting for input and then write it back */
    while (1)
    {
        cli_size = sizeof(cli_addr);
        if ((client_sock = accept(sock, (struct sockaddr *) &cli_addr,
                                    &cli_size)) == -1)
        {
            close(sock);
            fprintf(stderr, "Error accepting connection.\n");
            return EXIT_FAILURE;
        }

        readret = 0;
        while(1) {
            // recv_begin
            if((readret = recv(client_sock, buf, 8192, 0)) >= 1)
            {
                // parse 解析模块
                Request *request = parse(buf, readret, client_sock);

                // response 响应模块
                handle_request(request, buf, sbuf, client_sock);
            
                // reset 重置操作
                free(request);
                memset(buf, 0, 8192);
                memset(sbuf,0, 8192);
            }
        }

        if (readret == -1)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error reading from client socket.\n");
            return EXIT_FAILURE;
        }

        if (close_socket(client_sock))
        {
            close_socket(sock);
            fprintf(stderr, "Error closing client socket.\n");
            return EXIT_FAILURE;
        }
    }

    close_socket(sock);

    return EXIT_SUCCESS;
}

// 响应模块
void handle_request(Request *request, char *buf, char *sbuf, int client_sock){
    if(request == NULL){
        strcpy(sbuf, RESPONSE_400);
        send(client_sock, sbuf, strlen(sbuf), 0);
        return;
    }
    else if(strcmp(request->http_method, "GET") == 0 || strcmp(request->http_method, "HEAD") == 0){
        if(strcmp(request->http_version, "HTTP/1.1") != 0){
            strcpy(sbuf, RESPONSE_505);
            send(client_sock, sbuf, strlen(sbuf), 0);
            return ;
        }
        char file_path[1024];
        strcpy(file_path, request->http_uri);
        if(is_dir(request->http_uri)){
            if(strcmp(request->http_uri, "/") == 0){
                strcpy(file_path, URI_Default);
            }
            else{
                strcat(file_path, URI_Default);
            }
        }
        fprintf(stderr, file_path);
        int fd = open(file_path, O_RDONLY);
        if(fd < 0){
            strcpy(sbuf, RESPONSE_404);
            send(client_sock, sbuf, strlen(sbuf), 0);
            return ;
        }
        char data[BUF_SIZE];
        int readret = read(fd, data, BUF_SIZE);
        if(readret < 0){
            ERROR_LOG(file_path);
            close(fd);
            return ;
        }
        data[readret] = '\0';
        // 添加头部
        strcpy(sbuf, RESPONSE_200);
        add_header(request, sbuf, file_path);

        if(strcmp(request->http_method, "GET") == 0){
            // GET
            strcat(sbuf, data);
        }
        send(client_sock, sbuf, strlen(sbuf), 0);
        return ;
    }
    else if(strcmp(request->http_method, "POST") == 0){
        if(strcmp(request->http_version, "HTTP/1.1") != 0){
            strcpy(sbuf, RESPONSE_505);
            send(client_sock, sbuf, strlen(sbuf), 0);
            return ;
        }
        // echo
        strcpy(sbuf, buf);
        send(client_sock, sbuf, strlen(sbuf), 0);
    }
    else{
        strcpy(sbuf, RESPONSE_501);
        send(client_sock, sbuf, strlen(sbuf), 0);
    }
}

// 路径是否为目录
int is_dir(char *file_path){
    int len = strlen(file_path);
    if(file_path[len-1] == '/'){
        return 1;
    }
    return 0;
}

// 添加头部模块
void add_header(Request *request, char *sbuf, char *file_path){
    int i = 0;
    char msg[1024];
    for( ; i < request->header_count; i++){
        if(strcmp(request->headers[i].header_name, "Connection") == 0){
            sprintf(msg, "%s: %s\r\n", request->headers[i].header_name, request->headers[i].header_value);
            strcat(sbuf, msg);
            break;
        }
    }
    // stat
    struct stat st;
    if(stat(file_path, &st) == 0){
        sprintf(msg, "Content-Length: %ld\r\n", st.st_size);
        strcat(sbuf, msg);
    }
    strcat(sbuf, "\r\n");
    return ;
}